import fs from "node:fs";
for (const f of process.argv.slice(2)) {
  const s = fs.readFileSync(f, "utf8").split("RecentQueue")[1].split("PendingEvent")[0];
  const ev = [...s.matchAll(/eventTime=(\d+).*?action=(\w+).*?pointers=\[0: \(([\d.]+), ([\d.]+)\)\]/g)].map((m) => ({ t: +m[1] / 1e6, a: m[2], y: +m[4] }));
  const up = ev.findLast((e) => e.a === "UP");
  const last = ev.filter((e) => e.a === "MOVE" && e.t <= up.t).at(-1);
  console.log(f.split("/").at(-1).padEnd(36), "lastMove->UP", String(Math.round(up.t - last.t)).padStart(3), "ms  lastMoveY", String(last.y).padStart(6), " gaps", ev.slice(1).map((e, i) => Math.round(e.t - ev[i].t)).join(","));
}
