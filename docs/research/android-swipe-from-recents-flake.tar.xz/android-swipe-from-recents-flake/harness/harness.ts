import fs from "node:fs";
import path from "node:path";
import timers from "node:timers/promises";

const REPO = process.env["CUP_CHECKOUT"] ?? process.cwd();
const { checkAndroidHost } = await import(`${REPO}/qa/mobile-e2e/src/android/preflight.ts`);
const { bootEmulator } = await import(`${REPO}/qa/mobile-e2e/src/android/emulator.ts`);
const { run } = await import(`${REPO}/qa/mobile-e2e/src/host.ts`);

const [variant = "current", countArgument = "30", loadArgument = "0", outArgument = "out"] = process.argv.slice(2);
const count = Number(countArgument);
const loadLoops = Number(loadArgument);
const outDir = path.resolve(outArgument, variant);
fs.mkdirSync(outDir, { recursive: true });

const APP = "com.android.settings";
const ACTIVITY = `${APP}/.Settings`;

const host = await checkAndroidHost();
const emulator = await bootEmulator(host);
const serial: string = emulator.serial;
const adb = (args: string[], timeoutMs = 30_000) =>
  Promise.race([
    run(host.adb, ["-s", serial, ...args]),
    timers.setTimeout(timeoutMs).then(() => {
      throw new Error(`adb ${args.join(" ")} timed out after ${timeoutMs} ms`);
    }),
  ]) as Promise<{ stdout: string; exitCode: number }>;

async function settingsTasks(): Promise<number> {
  const { stdout } = await adb(["shell", "dumpsys", "activity", "recents"]);
  return [...stdout.matchAll(/^  \* Recent #\d+: Task\{[^\n]*\bA=(?:\d+:)?com\.android\.settings\b/gmu)].length;
}

async function cardBounds(): Promise<{ x: number; y: number; width: number; height: number } | undefined> {
  const { stdout } = await adb(["exec-out", "uiautomator", "dump", "/dev/tty"]);
  const match = /resource-id="[^"]*:id\/snapshot"[^>]*bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/u.exec(stdout);
  if (match === null) return undefined;
  const [x1, y1, x2, y2] = match.slice(1).map(Number) as [number, number, number, number];
  return { x: x1, y: y1, width: x2 - x1, height: y2 - y1 };
}

async function swipe(bounds: { x: number; y: number; width: number; height: number }) {
  const centerX = Math.round(bounds.x + bounds.width / 2);
  const centerY = Math.round(bounds.y + bounds.height / 2);
  switch (variant) {
    case "current":
      await adb(["shell", "input", "swipe", String(centerX), String(centerY), String(centerX), "0", "200"]);
      return;
    case "stall": {
      const steps = [0.25, 0.5, 0.71].map((f) => Math.round(centerY * (1 - f)));
      const moves = steps.map((y) => `input motionevent MOVE ${centerX} ${y}`).join("; ");
      await adb(["shell", `input motionevent DOWN ${centerX} ${centerY}; ${moves}; sleep 0.1; input motionevent UP ${centerX} 0`]);
      return;
    }
    case "hold": {
      const steps = [0.25, 0.5, 0.75, 1].map((f) => Math.round(centerY * (1 - f)));
      const moves = steps.map((y) => `input motionevent MOVE ${centerX} ${y}`).join("; ");
      await adb(["shell", `input motionevent DOWN ${centerX} ${centerY}; ${moves}; sleep 0.3; input motionevent UP ${centerX} 0`]);
      return;
    }
    case "hold-70":
    case "hold-80":
    case "hold-98":
    case "hold-85":
    case "hold-95":
    case "hold-bottom": {
      const startY = Math.round(bounds.y + bounds.height * (variant === "hold-70" ? 0.7 : variant === "hold-80" ? 0.8 : variant === "hold-98" ? 0.98 : variant === "hold-85" ? 0.85 : variant === "hold-95" ? 0.95 : 0.9));
      const steps = [0.25, 0.5, 0.75, 1].map((f) => Math.round(startY * (1 - f)));
      const moves = steps.map((y) => `input motionevent MOVE ${centerX} ${y}`).join("; ");
      await adb(["shell", `input motionevent DOWN ${centerX} ${startY}; ${moves}; sleep 0.3; input motionevent UP ${centerX} 0`]);
      return;
    }
    case "far": {
      const endY = -Number(process.env.FAR_END ?? "1500");
      const steps = [0.25, 0.5, 0.75, 1].map((f) => Math.round(centerY + (endY - centerY) * f));
      const moves = steps.map((y) => `input motionevent MOVE ${centerX} ${y}`).join(" && ");
      await adb(["shell", `input motionevent DOWN ${centerX} ${centerY} && ${moves} && sleep 0.3 && input motionevent UP ${centerX} ${endY}`]);
      return;
    }
    default:
      throw new Error(`Unknown variant ${variant}`);
  }
}

try {
  for (let index = 0; index < loadLoops; index += 1) {
    void adb(["shell", "sh -c 'while true; do :; done' >/dev/null 2>&1 &"]).catch(() => undefined);
  }
  const results: string[] = [];
  for (let iteration = 1; iteration <= count; iteration += 1) {
    await adb(["shell", "am", "start", "-W", "-n", ACTIVITY]);
    await adb(["shell", "input", "keyevent", "KEYCODE_APP_SWITCH"]);
    let bounds: Awaited<ReturnType<typeof cardBounds>>;
    const settleDeadline = Date.now() + 15_000;
    let previous: string | undefined;
    for (;;) {
      if (Date.now() > settleDeadline) {
        const { stdout: tree } = await adb(["exec-out", "uiautomator", "dump", "/dev/tty"]);
        throw new Error(`card never settled: ${previous}\n${tree.slice(0, 3000)}`);
      }
      bounds = await cardBounds();
      if (bounds === undefined && Date.now() > settleDeadline - 12_000) {
        await adb(["shell", "input", "keyevent", "KEYCODE_APP_SWITCH"]);
        await timers.setTimeout(1_000);
      }
      const key = JSON.stringify(bounds);
      if (bounds !== undefined && key === previous) break;
      previous = key;
      await timers.setTimeout(300);
    }
    const tasksBefore = await settingsTasks();
    await swipe(bounds!);
    const { stdout: input } = await adb(["shell", "dumpsys", "input"]);
    let removed = false;
    const removeDeadline = Date.now() + 5_000;
    while (Date.now() < removeDeadline) {
      if ((await settingsTasks()) < tasksBefore) {
        removed = true;
        break;
      }
      await timers.setTimeout(250);
    }
    fs.writeFileSync(path.join(outDir, `iteration-${iteration}-${removed ? "removed" : "kept"}-input.txt`), input);
    if (!removed) {
      const { stdout: tree } = await adb(["exec-out", "uiautomator", "dump", "/dev/tty"]);
      fs.writeFileSync(path.join(outDir, `iteration-${iteration}-kept-ui.xml`), tree);
    }
    const line = `${variant} iteration=${iteration} tasksBefore=${tasksBefore} ${removed ? "REMOVED" : "KEPT"}`;
    results.push(line);
    console.log(line);
    await adb(["shell", "input", "keyevent", "KEYCODE_HOME"]);
    if (!removed) await adb(["shell", "am", "force-stop", APP]);
  }
  const kept = results.filter((line) => line.endsWith("KEPT")).length;
  console.log(`SUMMARY variant=${variant} load=${loadLoops} kept=${kept}/${count}`);
} finally {
  await emulator.stop();
}
