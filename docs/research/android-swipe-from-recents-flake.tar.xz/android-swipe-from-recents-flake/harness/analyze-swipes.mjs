import fs from "node:fs";
import path from "node:path";
const roots = process.argv.slice(2);
const files = [];
const walk = (dir) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) walk(p); else if (e.name.endsWith("-input.txt")) files.push(p); } };
roots.forEach(walk);
for (const file of files.sort()) {
  const stem = file.replace(/-input\.txt$/u, "");
  const recents = fs.readFileSync(`${stem}-recents.txt`, "utf8");
  const removed = !/\bA=(?:\d+:)?audio\.cup\.app\b/u.test(recents);
  const input = fs.readFileSync(file, "utf8");
  const queue = input.split("RecentQueue")[1]?.split("PendingEvent")[0] ?? "";
  const events = [...queue.matchAll(/eventTime=(\d+), source=TOUCHSCREEN.*?action=(\w+).*?pointers=\[0: \(([\d.]+), ([\d.]+)\)\]/gu)].map((m) => ({ t: Number(m[1]) / 1e6, action: m[2], y: Number(m[4]) }));
  const up = events.findLast((e) => e.action === "UP");
  const before = events.filter((e) => e.action === "MOVE" && up && e.t <= up.t);
  const last = before.at(-1);
  const gaps = events.slice(1).map((e, i) => Math.round(e.t - events[i].t));
  const recentMoves = before.filter((e) => up && up.t - e.t <= 100);
  const velocity = recentMoves.length >= 2 ? ((recentMoves.at(-1).y - recentMoves[0].y) / (recentMoves.at(-1).t - recentMoves[0].t)).toFixed(2) : "n/a";
  console.log(`${removed ? "REMOVED" : "KEPT   "} ${path.relative(process.cwd(), stem)} lastMove->UP=${last && up ? Math.round(up.t - last.t) : "?"}ms lastMoveY=${last?.y} movesIn100ms=${recentMoves.length} v=${velocity}px/ms gaps=${gaps.join(",")}`);
}
