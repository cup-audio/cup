Probe archive for docs/research/ios-simulator-webview-audio.md (patricktree/cup#374), 2026-11-14.

Throwaway, never committed to the repository:
- test-worker-throwaway.diff: 60-second fake speech segments (a 3:48 track of four segments) and a 256x256 four-colour cover PNG in the test Worker.
- zz-probe.test.ts: a Vitest spec for qa/mobile-e2e/test/ios/. It uses the suite's useMobileApp() fixture (own simulator, test Worker, fake auth provider), signs in from the landing page with signInFromLandingPage(), writes ready.json and then runs a file-based REPL: every <name>.cmd.js dropped into $PROBE_DIR runs as an async function body with ctx = { app, device, driver, udid, fs, path, PROBE_DIR }, and its result lands in <name>.out.json. A file named "stop" ends the test, and the suite's teardown deletes the simulator.
- p.mjs: drops one command file and waits for its result: node p.mjs <name> <timeoutSeconds> <command.js>.

Run:
  pnpm run build
  PROBE_DIR=<dir> pnpm --filter @cup/mobile-e2e test:e2e --project ios test/ios/zz-probe.test.ts

Commands, in the order used (commands/):
  state.js, instrument.js (patches HTMLMediaElement.play/pause to capture Cup's audio element and log its events; a 5 s timer requests /api/auth/config through the patched fetch, i.e. CapacitorHttp), play.js (taps Cup's Play), reqs.js / wlogs.js / seq.js (test Worker request log and Wrangler status lines),
  lock.js, wake.js, npsrc.js, npbtn.js with setbtn-*.js (tap lock-screen Now Playing buttons), weblog.js, unlock.js, appstate.js, ctxs.js,
  cc.js / src.js (Control Center), ms.js (registers mediaSession action handlers and setPositionState), lockdump.js, scrub2.js, bogus.js with mode-*.js,
  reload.js, seekend.js, proxy.js / proxy24.js (throttling TCP proxy in front of the test Worker, 64 or 24 KiB/s), throttled.js, locklisten.js, fulllog.js, bgpaused.js.

Outputs:
- locked-throttled-listen.json: page log and proxy log of the locked whole listen through the 24 KiB/s proxy.
- simlog/simulator.log: RunningBoard state calculations for Cup's processes, WebKit GPU process MediaRemote logs, mediaremoted now-playing items.
- screenshots/: xcrun simctl io screenshots, downscaled.
