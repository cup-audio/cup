await ctx.driver.$('button[aria-label="Play"]').click();
await new Promise((r) => setTimeout(r, 4000));
return await ctx.driver.execute(() => {
  const a = window.__probeAudio;
  return { log: window.__probe.log, src: a?.src.replace(/token=[^&]+/, "token=…"), at: a?.currentTime, dur: a?.duration, paused: a?.paused, meta: navigator.mediaSession.metadata && { title: navigator.mediaSession.metadata.title, artwork: navigator.mediaSession.metadata.artwork.map((x) => x.src.replace(/token=[^&]+/, "token=…")) }, playbackState: navigator.mediaSession.playbackState };
});
