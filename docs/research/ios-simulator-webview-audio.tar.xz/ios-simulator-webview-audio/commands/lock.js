const ctxName = await ctx.driver.getContext();
globalThis.__webCtx = typeof ctxName === "string" ? ctxName : ctxName?.id;
await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: lock");
await new Promise((r) => setTimeout(r, 1500));
const locked = await ctx.driver.execute("mobile: isLocked");
await ctx.driver.execute(() => window.__probe?.logf?.("LOCK"), []).catch(() => {});
return { locked, webCtx: globalThis.__webCtx, at: Date.now() };
