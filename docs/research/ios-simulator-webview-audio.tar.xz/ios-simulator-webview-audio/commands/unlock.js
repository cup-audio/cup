await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: dragFromToForDuration", { duration: 0.3, fromX: 201, fromY: 865, toX: 201, toY: 300 });
await new Promise((r) => setTimeout(r, 1500));
await ctx.driver.execute("mobile: activateApp", { bundleId: "audio.cup.app" });
await new Promise((r) => setTimeout(r, 2000));
return { locked: await ctx.driver.execute("mobile: isLocked"), state: await ctx.driver.execute("mobile: queryAppState", { bundleId: "audio.cup.app" }) };
