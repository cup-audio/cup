const reqs = ctx.app.worker.requests();
const out = [];
for (const r of reqs) {
  const m = /probe=(\d+)/.exec(r.path);
  if (m) out.push(`p${m[1]}`);
  else if (r.method === "PUT") out.push(`PUT(${(r.body ?? "").slice(0, 80)})`);
  else if (r.path.includes("narration-track")) out.push(`TRACK range=${r.headers["range"]}`);
  else out.push(`${r.method} ${r.path.slice(0, 50)}`);
}
return out.slice(Number(globalThis.__seqFrom ?? 0)).join(" | ");
