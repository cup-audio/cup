const port = globalThis.__proxy.address().port;
const r = await ctx.driver.execute((port) => {
  const a = window.__probeAudio;
  const u = new URL(a.src);
  u.port = String(port);
  a.src = u.toString();
  window.__probe.logf(`src -> proxied port ${port}`);
  a.play();
  return u.toString().replace(/token=[^&]+/, "token=…");
}, port);
await new Promise((r) => setTimeout(r, 10000));
const mid = await ctx.driver.execute(() => { const a = window.__probeAudio; return { at: a.currentTime, buf: a.buffered.length ? a.buffered.end(a.buffered.length - 1) : null, dur: a.duration }; });
await ctx.driver.execute(() => { const a = window.__probeAudio; a.currentTime = a.duration - 8; });
await new Promise((r) => setTimeout(r, 14000));
const log = await ctx.driver.execute(() => window.__probe.log.filter((l) => !l.includes("tick")).slice(-25));
return { r, mid, log, proxy: globalThis.__proxyLog };
