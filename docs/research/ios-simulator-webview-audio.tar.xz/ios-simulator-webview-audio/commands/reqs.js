const since = Number(globalThis.__reqSince ?? 0);
const reqs = ctx.app.worker.requests();
return reqs.slice(since).map((r) => `${r.method} ${r.path.replace(/token=[^&]+/, "token=…")} range=${r.headers["range"] ?? "-"} origin=${r.headers["origin"] ?? "-"} ua=${(r.headers["user-agent"] ?? "").slice(0, 40)}`);
