await ctx.driver.switchContext("NATIVE_APP");
const src = await ctx.driver.getPageSource();
const f = ctx.path.join(ctx.PROBE_DIR, "..", `src-${Date.now()}.xml`);
await ctx.fs.writeFile(f, src);
return f;
