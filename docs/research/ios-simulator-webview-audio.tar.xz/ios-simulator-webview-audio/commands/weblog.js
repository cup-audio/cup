const contexts = await ctx.driver.execute("mobile: getContexts");
const web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
const out = await ctx.driver.execute(() => {
  const a = window.__probeAudio;
  return { log: window.__probe.log.slice(-Number(window.__probeTail ?? 30)), at: a?.currentTime, paused: a?.paused, vis: document.visibilityState };
});
await ctx.driver.switchContext("NATIVE_APP");
return out;
