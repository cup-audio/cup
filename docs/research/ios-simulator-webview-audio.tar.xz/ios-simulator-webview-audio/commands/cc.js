// play in Cup, then open Control Center and dump Now Playing.
const contexts = await ctx.driver.execute("mobile: getContexts");
const web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
const playBtn = await ctx.driver.$('button[aria-label="Play"]');
if (await playBtn.isExisting()) await playBtn.click();
await new Promise((r) => setTimeout(r, 3000));
await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: dragFromToForDuration", { duration: 0.4, fromX: 360, fromY: 3, toX: 360, toY: 500 });
await new Promise((r) => setTimeout(r, 2500));
const src = await ctx.driver.getPageSource();
await ctx.fs.writeFile(ctx.path.join(ctx.PROBE_DIR, "..", `cc-${Date.now()}.xml`), src);
return src.split("\n").filter((l) => /NowPlaying|Track position|TrackPosition|Rewind|Pause|"Play"|Fast-forward|Media/.test(l)).map((l) => l.trim().slice(0, 260));
