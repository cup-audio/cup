await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: tap", { x: 200, y: 150 });
await new Promise((r) => setTimeout(r, 1500));
const src = await ctx.driver.getPageSource();
const labels = [...src.matchAll(/<XCUIElementType(\w+)[^>]*?(?:label="([^"]*)")[^>]*?(?:value="([^"]*)")?/g)].map((m) => `${m[1]} ${m[2]} ${m[3] ?? ""}`).filter((l) => !/^(Other|Window)  ?$/.test(l));
return { locked: await ctx.driver.execute("mobile: isLocked"), labels: labels.slice(0, 80) };
