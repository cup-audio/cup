const contexts = await ctx.driver.execute("mobile: getContexts");
const web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
const log = await ctx.driver.execute(() => window.__probe.log);
await ctx.driver.switchContext("NATIVE_APP");
const out = { log, proxy: globalThis.__proxyLog, lockedAt: globalThis.__lockedAt };
await ctx.fs.writeFile(ctx.path.join(ctx.PROBE_DIR, "..", `fulllog-${Date.now()}.json`), JSON.stringify(out, null, 2));
return out;
