await ctx.driver.switchContext("NATIVE_APP");
const src = await ctx.driver.getPageSource();
await ctx.fs.writeFile(ctx.path.join(ctx.PROBE_DIR, `..`, `src-${Date.now()}.xml`), src);
const lines = src.split("\n").filter((l) => /Playing|Track position|Rewind|Pause|Play"|Fast-forward|Elapsed|Remaining|Seek|Skip|Previous|Next|Image/.test(l));
return lines.map((l) => l.trim().slice(0, 300));
