await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: tap", { x: 200, y: 150 });
await new Promise((r) => setTimeout(r, 800));
const tp = await ctx.driver.$('-ios predicate string:name == "TrackPosition"');
const rect = await ctx.driver.getElementRect(tp.elementId);
const before = await tp.getAttribute("value");
const w = rect.width;
await ctx.driver.action("pointer", { parameters: { pointerType: "touch" } })
  .move({ origin: tp, x: Math.round(-w * 0.05), y: 0 })
  .down()
  .pause(200)
  .move({ origin: tp, x: Math.round(w * 0.42), y: 0, duration: 600 })
  .pause(200)
  .up()
  .perform();
await new Promise((r) => setTimeout(r, 1500));
const after = await ctx.driver.$('-ios predicate string:name == "TrackPosition"').getAttribute("value");
return { rect, before, after };
