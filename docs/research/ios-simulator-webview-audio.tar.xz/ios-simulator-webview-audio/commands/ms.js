await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: pressButton", { name: "home" });
await new Promise((r) => setTimeout(r, 1000));
await ctx.driver.execute("mobile: activateApp", { bundleId: "audio.cup.app" });
await new Promise((r) => setTimeout(r, 1500));
const contexts = await ctx.driver.execute("mobile: getContexts");
const web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
const out = await ctx.driver.execute(() => {
  const log = window.__probe.logf;
  const a = window.__probeAudio;
  const ms = navigator.mediaSession;
  const results = {};
  const handlers = {
    play: () => { log("MS handler play"); a.play(); },
    pause: () => { log("MS handler pause"); a.pause(); },
    seekto: (d) => { log(`MS handler seekto ${JSON.stringify({ seekTime: d.seekTime, fastSeek: d.fastSeek })}`); a.currentTime = d.seekTime; },
    seekforward: (d) => { log(`MS handler seekforward offset=${d.seekOffset}`); a.currentTime = Math.min(a.duration, a.currentTime + (d.seekOffset ?? 30)); },
    seekbackward: (d) => { log(`MS handler seekbackward offset=${d.seekOffset}`); a.currentTime = Math.max(0, a.currentTime - (d.seekOffset ?? 30)); },
  };
  for (const [k, fn] of Object.entries(handlers)) {
    try { ms.setActionHandler(k, fn); results[k] = "ok"; } catch (e) { results[k] = String(e); }
  }
  const sps = () => { try { ms.setPositionState({ duration: a.duration, playbackRate: a.playbackRate, position: a.currentTime }); } catch (e) { log(`setPositionState ERR ${e}`); } };
  for (const ev of ["play", "pause", "seeked", "ratechange", "durationchange"]) a.addEventListener(ev, sps);
  sps();
  results.positionState = "set";
  return { results, at: a.currentTime, paused: a.paused };
});
return out;
