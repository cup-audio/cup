await ctx.driver.switchContext("NATIVE_APP");
if (!(await ctx.driver.execute("mobile: isLocked"))) {
  await ctx.driver.execute("mobile: lock");
  await new Promise((r) => setTimeout(r, 1500));
}
await ctx.driver.execute("mobile: tap", { x: 200, y: 150 });
await new Promise((r) => setTimeout(r, 1500));
const src = await ctx.driver.getPageSource();
return src.split("\n").filter((l) => /NowPlaying|TrackPosition/.test(l)).map((l) => {
  const g = (k) => (new RegExp(`${k}="([^"]*)"`).exec(l) ?? [])[1];
  return `${g("name")} | ${g("label")} | ${g("value") ?? ""} | enabled=${g("enabled")}`;
});
