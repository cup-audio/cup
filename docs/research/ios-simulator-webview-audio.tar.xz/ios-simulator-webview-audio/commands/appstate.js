await ctx.driver.switchContext("NATIVE_APP");
const state = await ctx.driver.execute("mobile: queryAppState", { bundleId: "audio.cup.app" });
const contexts = await ctx.driver.execute("mobile: getContexts");
return { state, contexts, locked: await ctx.driver.execute("mobile: isLocked") };
