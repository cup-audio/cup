return await ctx.driver.execute(() => {
  const a = window.__probeAudio ?? null;
  return {
    path: location.pathname,
    origin: location.origin,
    ua: navigator.userAgent,
    ms: "mediaSession" in navigator,
    meta: navigator.mediaSession?.metadata ? { title: navigator.mediaSession.metadata.title, artwork: navigator.mediaSession.metadata.artwork } : null,
    buttons: [...document.querySelectorAll("button")].map((b) => b.getAttribute("aria-label") || b.textContent).slice(0, 40),
    text: document.body.innerText.slice(0, 600),
  };
});
