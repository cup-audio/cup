await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: tap", { x: 200, y: 150 });
await new Promise((r) => setTimeout(r, 800));
const read = () => ctx.driver.$('-ios predicate string:name == "TrackPosition"').getAttribute("value");
const before = await read();
// Track position slider on the lock screen platter, in screen points (iPhone 17: 402 x 874).
await ctx.driver.execute("mobile: dragFromToForDuration", { duration: 0.5, fromX: 75, fromY: 662, toX: Number(globalThis.__toX ?? 200), toY: 662 });
await new Promise((r) => setTimeout(r, 1500));
return { before, after: await read() };
