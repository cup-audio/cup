globalThis.__mode = "clear";
return 1;
