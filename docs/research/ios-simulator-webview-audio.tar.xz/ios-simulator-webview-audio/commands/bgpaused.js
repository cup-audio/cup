// Paused, then HOME for 75 s, then back.
await ctx.driver.switchContext("NATIVE_APP");
let contexts = await ctx.driver.execute("mobile: getContexts");
let web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
await ctx.driver.execute(() => { window.__probe.log.length = 0; window.__probe.logf(`BG PAUSED START paused=${window.__probeAudio.paused}`); });
await ctx.driver.switchContext("NATIVE_APP");
const t = new Date().toISOString();
await ctx.driver.execute("mobile: pressButton", { name: "home" });
await new Promise((r) => setTimeout(r, 75000));
const state = await ctx.driver.execute("mobile: queryAppState", { bundleId: "audio.cup.app" });
await ctx.driver.execute("mobile: activateApp", { bundleId: "audio.cup.app" });
await new Promise((r) => setTimeout(r, 2000));
contexts = await ctx.driver.execute("mobile: getContexts");
web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
const log = await ctx.driver.execute(() => window.__probe.log);
await ctx.driver.switchContext("NATIVE_APP");
return { t, stateWhileBackground: state, log };
