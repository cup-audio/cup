// Start a throttled listen from 0 through Cup's element, then lock.
globalThis.__seqFrom = ctx.app.worker.requests().length;
const port = globalThis.__proxy.address().port;
await ctx.driver.execute((port) => {
  window.__probe.log.length = 0;
  const a = window.__probeAudio;
  const u = new URL(a.src);
  u.port = String(port);
  a.src = u.toString();
  window.__probe.logf(`LISTEN START src -> proxied port ${port}`);
  a.play();
}, port);
await new Promise((r) => setTimeout(r, 4000));
await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: lock");
globalThis.__lockedAt = new Date().toISOString();
return { lockedAt: globalThis.__lockedAt, locked: await ctx.driver.execute("mobile: isLocked") };
