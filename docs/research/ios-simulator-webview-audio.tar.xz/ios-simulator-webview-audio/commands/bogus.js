const contexts = await ctx.driver.execute("mobile: getContexts");
const web = contexts.findLast((c) => c.id.startsWith("WEBVIEW_") && String(c.url).startsWith("capacitor://localhost"));
await ctx.driver.switchContext(web.id);
const r = await ctx.driver.execute((mode) => {
  const ms = navigator.mediaSession;
  const a = window.__probeAudio;
  if (mode === "bogus") {
    ms.setPositionState({ duration: 3600, playbackRate: 1, position: 1800 });
    return "set bogus 1800 of 3600";
  }
  if (mode === "clear") {
    for (const k of ["play", "pause", "seekto", "seekforward", "seekbackward"]) ms.setActionHandler(k, null);
    ms.setPositionState();
    return "cleared handlers and position state";
  }
  if (mode === "meta") {
    ms.metadata = new MediaMetadata({ title: "Probe title changed", artist: "Probe artist", album: "Probe album", artwork: ms.metadata?.artwork ?? [] });
    return "meta";
  }
  return "?";
}, globalThis.__mode);
await ctx.driver.switchContext("NATIVE_APP");
await ctx.driver.execute("mobile: lock"); await new Promise((r) => setTimeout(r, 1500)); await ctx.driver.execute("mobile: tap", { x: 200, y: 150 });
await new Promise((r) => setTimeout(r, 1500));
const src = await ctx.driver.getPageSource();
const np = src.split("\n").filter((l) => /NowPlaying.LabelView|TrackPosition|LeftButton|RightButton/.test(l)).map((l) => `${(/label="([^"]*)"/.exec(l) ?? [])[1]} ${(/value="([^"]*)"/.exec(l) ?? [])[1] ?? ""}`);
return { r, np };
