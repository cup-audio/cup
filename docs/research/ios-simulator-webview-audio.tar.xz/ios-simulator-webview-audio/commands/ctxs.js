await ctx.driver.switchContext("NATIVE_APP");
return { contexts: await ctx.driver.execute("mobile: getContexts"), state: await ctx.driver.execute("mobile: queryAppState", { bundleId: "audio.cup.app" }), locked: await ctx.driver.execute("mobile: isLocked") };
