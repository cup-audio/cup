globalThis.__btn = "LeftButton";
return "ok";
