// Play from segment 4, then seek to 5 s before the end and let it play out.
await ctx.driver.$('button[aria-label="Play segment 4"]').click();
await new Promise((r) => setTimeout(r, 3000));
await ctx.driver.execute(() => { const a = window.__probeAudio; a.currentTime = a.duration - 5; });
await new Promise((r) => setTimeout(r, 9000));
const log = await ctx.driver.execute(() => window.__probe.log.filter((l) => !l.includes("tick")));
return log;
