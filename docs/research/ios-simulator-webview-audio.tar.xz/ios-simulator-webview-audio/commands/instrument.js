return await ctx.driver.execute((apiOrigin) => {
  const t0 = Date.now();
  window.__probe = { t0, log: [] };
  const log = (msg) => window.__probe.log.push(`${((Date.now() - t0) / 1000).toFixed(1)}s ${document.visibilityState} ${msg}`);
  window.__probe.logf = log;
  document.addEventListener("visibilitychange", () => log("visibilitychange"));
  window.addEventListener("pagehide", () => log("pagehide"));
  window.addEventListener("pageshow", () => log("pageshow"));
  const origPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    if (window.__probeAudio !== this) {
      window.__probeAudio = this;
      for (const ev of ["play", "playing", "pause", "ended", "seeking", "seeked", "waiting", "stalled", "error", "loadedmetadata", "durationchange", "ratechange", "suspend", "emptied", "abort"]) {
        this.addEventListener(ev, () => log(`audio:${ev} at=${this.currentTime.toFixed(1)} err=${this.error?.code ?? "-"}`));
      }
    }
    log(`play() called at=${this.currentTime.toFixed(1)}`);
    return origPlay.apply(this, args);
  };
  const origPause = HTMLMediaElement.prototype.pause;
  HTMLMediaElement.prototype.pause = function (...args) {
    log(`pause() called at=${this.currentTime.toFixed(1)}`);
    return origPause.apply(this, args);
  };
  // Periodic tick plus a periodic request through the patched fetch (CapacitorHttp).
  let n = 0;
  window.__probe.timer = setInterval(async () => {
    const a = window.__probeAudio;
    const i = ++n;
    const state = a ? `at=${a.currentTime.toFixed(1)} paused=${a.paused} buf=${a.buffered.length ? a.buffered.end(a.buffered.length - 1).toFixed(1) : "-"}` : "noaudio";
    try {
      const r = await fetch(`${apiOrigin}/api/auth/config?probe=${i}`);
      log(`tick#${i} ${state} fetch ${r.status}`);
    } catch (e) {
      log(`tick#${i} ${state} fetch ERR ${e}`);
    }
  }, 5000);
  return { ok: true, capHttp: !!window.CapacitorWebFetch, fetchNative: String(fetch).slice(0, 80) };
}, ctx.app.apiOrigin);
