const all = ctx.app.worker.logs.join("").split("\n");
return all.filter((l) => !l.includes("[test-worker:request]") && /narration-track|position|\b(20\d|30\d|4\d\d|5\d\d)\b/.test(l) && !l.includes("auth/config")).slice(-40).map((l) => l.replace(/token=[^&\s]+/, "token=…"));
