globalThis.__btn = "RightButton";
return "ok";
