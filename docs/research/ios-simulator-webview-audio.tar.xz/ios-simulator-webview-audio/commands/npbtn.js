// globalThis.__btn: which NowPlaying button name suffix to tap
await ctx.driver.switchContext("NATIVE_APP");
const name = globalThis.__btn;
const read = async () => {
  const tp = await ctx.driver.$('-ios predicate string:name == "TrackPosition"');
  const c = await ctx.driver.$('-ios predicate string:name == "UIA.MediaControls.NowPlaying.CenterButton"');
  return { pos: await tp.getAttribute("value").catch((e) => String(e)), center: await c.getAttribute("label").catch((e) => String(e)) };
};
const before = await read();
const el = await ctx.driver.$(`-ios predicate string:name == "UIA.MediaControls.NowPlaying.${name}"`);
const label = await el.getAttribute("label");
await el.click();
await new Promise((r) => setTimeout(r, 2500));
const after = await read();
return { tapped: label, before, after, at: new Date().toISOString() };
