globalThis.__btn = "CenterButton";
return "ok";
