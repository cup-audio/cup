globalThis.__mode = "bogus";
return 1;
