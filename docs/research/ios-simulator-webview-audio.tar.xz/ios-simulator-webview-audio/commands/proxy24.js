const net = process.getBuiltinModule("node:net");
const target = Number(new URL(ctx.app.worker.origin).port);
const RATE = 24 * 1024; // bytes per second
const t0 = Date.now();
const plog = (globalThis.__proxyLog = []);
const L = (m) => plog.push(`${((Date.now() - t0) / 1000).toFixed(1)}s ${m}`);
const server = net.createServer((sock) => {
  const id = Math.random().toString(36).slice(2, 6);
  L(`conn ${id} open`);
  const up = net.connect(target, "127.0.0.1");
  sock.on("data", (d) => {
    const s = d.toString("latin1");
    const m = /^(GET|HEAD|PUT|POST) (\S+)/m.exec(s);
    if (m) L(`conn ${id} ${m[1]} ${m[2].replace(/token=[^&\s]+/, "token=…").slice(0, 90)} range=${(/^range: (.*)$/im.exec(s) ?? [])[1]?.trim() ?? "-"}`);
    up.write(d);
  });
  up.on("data", (d) => {
    const m = /HTTP\/1\.1 (\d{3}[^\r\n]*)/.exec(d.subarray(0, 200).toString("latin1"));
    if (m) L(`conn ${id} <- ${m[1]} ${(/content-range: ([^\r\n]*)/i.exec(d.subarray(0, 2000).toString("latin1")) ?? [])[1] ?? ""}`);
    sock.write(d);
    up.pause();
    setTimeout(() => up.resume(), (d.length / RATE) * 1000);
  });
  const end = (w) => () => { L(`conn ${id} closed by ${w}`); sock.destroy(); up.destroy(); };
  sock.on("close", end("app"));
  up.on("close", end("worker"));
  sock.on("error", () => {});
  up.on("error", () => {});
});
await new Promise((r) => server.listen(0, "::", r));
globalThis.__proxy = server;
return { port: server.address().port };
