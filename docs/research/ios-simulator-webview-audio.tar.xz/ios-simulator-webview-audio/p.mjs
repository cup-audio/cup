// usage: node p.mjs <name> [timeoutSeconds] < body.js
import fs from "node:fs";
const S = "<scratchpad>/probe";
fs.mkdirSync(S, { recursive: true });
const n = `${Date.now()}-${process.argv[2] ?? "cmd"}`;
const body = fs.readFileSync(process.argv[4] ?? 0, "utf8");
fs.writeFileSync(`${S}/${n}.tmp`, body);
fs.renameSync(`${S}/${n}.tmp`, `${S}/${n}.cmd.js`);
const deadline = Date.now() + Number(process.argv[3] ?? 300) * 1000;
while (Date.now() < deadline) {
  if (fs.existsSync(`${S}/${n}.out.json`)) {
    process.stdout.write(fs.readFileSync(`${S}/${n}.out.json`, "utf8") + "\n");
    process.exit(0);
  }
  await new Promise((r) => setTimeout(r, 300));
}
console.log("TIMEOUT");
