// THROWAWAY probe for patricktree/cup#374; never commit.
/* oxlint-disable */
import fs from "node:fs/promises";
import path from "node:path";
import { test } from "vitest";

import { useMobileApp } from "#src/fixtures.ts";
import { asIosAppDevice } from "#src/ios/ios-app-device.ts";
import { signInFromLandingPage } from "#src/journeys.ts";

const PROBE_DIR = process.env["PROBE_DIR"]!;
const app = useMobileApp();

test("probe REPL", { timeout: 4 * 60 * 60_000 }, async () => {
  await fs.mkdir(PROBE_DIR, { recursive: true });
  const device = asIosAppDevice(app.device);
  await device.launch({ apiOrigin: app.apiOrigin });
  const driver = await device.webView();
  await signInFromLandingPage(device, driver);
  const udid: string = (device as any).target.udid;
  await fs.writeFile(
    path.join(PROBE_DIR, "ready.json"),
    JSON.stringify({ udid, apiOrigin: app.apiOrigin, worker: app.worker.origin }),
  );
  const ctx = { app, device, driver, udid, fs, path, PROBE_DIR };
  const AsyncFunction = Object.getPrototypeOf(async () => {}).constructor;
  for (;;) {
    const files = (await fs.readdir(PROBE_DIR)).filter((f) => f.endsWith(".cmd.js")).sort();
    if ((await fs.readdir(PROBE_DIR)).includes("stop")) break;
    for (const file of files) {
      const code = await fs.readFile(path.join(PROBE_DIR, file), "utf8");
      await fs.rename(path.join(PROBE_DIR, file), path.join(PROBE_DIR, `${file}.taken`));
      let out: unknown;
      try {
        out = { ok: await new AsyncFunction("ctx", code)(ctx) };
      } catch (error) {
        out = { error: String((error as Error)?.stack ?? error) };
      }
      await fs.writeFile(
        path.join(PROBE_DIR, file.replace(/\.cmd\.js$/, ".out.json")),
        JSON.stringify(out, null, 2),
      );
    }
    await new Promise((r) => setTimeout(r, 300));
  }
});
