#!/usr/bin/env bash
# Usage: run.sh <true|false> <out-dir> [network speed: full (default) or 80 kbps]. One background run against production https://cup.audio:
# launches Cup, evaluates fgs-probe.js (with or without the stub foreground service), taps Play,
# throttles the emulator's network to 80 kbps to keep the buffer small, presses HOME, turns the
# screen off 60 s later, and keeps Cup in the background for 11 minutes while monitor.sh records
# process states. Then it wakes the device, brings Cup back and reads the probe log.
set -uo pipefail
source "$(dirname "$0")/env.sh"
fgs="${1:?true or false}"; out="${2:?out dir}"; speed="${3:-full}"; mkdir -p "${out}"
adb emu network speed full >/dev/null
adb logcat -c
bash "${here}/launch.sh"
node "${here}/cdp-eval.mjs" 9333 "window.__useFgs = ${fgs}; $(cat "${here}/fgs-probe.js")"
adb shell input tap 540 1200
sleep 10
adb emu network speed "${speed}" >/dev/null
sleep 5
bash "${here}/monitor.sh" 0 1 | tee "${out}/monitor-foreground.txt"
adb shell input keyevent KEYCODE_HOME
date +%s > "${out}/home-at.txt"
bash "${here}/monitor.sh" 660 30 > "${out}/monitor.txt" &
mon=$!
sleep 60
adb shell input keyevent 26   # power: screen off
sleep 600
wait "${mon}"
adb shell input keyevent KEYCODE_WAKEUP
adb shell wm dismiss-keyguard
sleep 2
adb shell am start -n audio.cup.app/.MainActivity
sleep 6
adb emu network speed full >/dev/null
node "${here}/cdp-eval.mjs" 9333 "window.__probe.log" > "${out}/probe-log.json"
node "${here}/cdp-eval.mjs" 9333 "Capacitor.Plugins.ProbeForegroundService.stop()" > "${out}/stop.json" 2>&1
node "${here}/cdp-eval.mjs" 9333 "window.__audio.pause(), clearInterval(window.__probeTimer), clearInterval(window.__netTimer), 'stopped'"
adb logcat -d | grep -E "CupProbe|UnknownHost|resolve host|Freez|freez.*cup|ForegroundService|audio.cup.app" > "${out}/logcat.txt"
adb shell dumpsys activity processes audio.cup.app | grep -E "curProcState|isFrozen" > "${out}/after.txt"
echo done
