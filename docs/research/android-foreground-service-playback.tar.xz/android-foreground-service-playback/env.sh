# Sourced by the other probe scripts.
export ANDROID_HOME="${ANDROID_HOME:-${HOME}/Library/Android/sdk}"
export JAVA_HOME="${JAVA_HOME:-/Applications/Android Studio.app/Contents/jbr/Contents/Home}"
SERIAL="${ANDROID_SERIAL:-emulator-5600}"
adb() { "${ANDROID_HOME}/platform-tools/adb" -s "${SERIAL}" "$@"; }
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
