// Usage: node cdp-network.mjs <port> <url-substring>. Attaches to the first page of a WebView whose
// devtools socket is forwarded to localhost:<port>, enables the Network domain and prints one line
// per request whose URL contains <url-substring>: time, request ID, method, Range header, then the
// response's status, Content-Range and the page's origin, or the loading failure. Token query
// parameters are redacted. Runs until killed.
const [port, match] = process.argv.slice(2);
const pages = await (await fetch(`http://localhost:${port}/json`)).json();
const ws = new WebSocket(pages.find((p) => p.type === "page").webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
const start = Date.now();
const t = () => `${((Date.now() - start) / 1000).toFixed(1)}s`;
const redact = (u) => u.replace(/token=[^&]+/, "token=<redacted>");
const seen = new Map();
ws.addEventListener("message", (e) => {
  const { method, params } = JSON.parse(e.data);
  if (method === "Network.requestWillBeSent" && params.request.url.includes(match)) {
    seen.set(params.requestId, true);
    const h = params.request.headers;
    console.log(`${t()} ${params.requestId} send ${params.request.method} ${redact(params.request.url)} range=${h.Range ?? h.range ?? "-"} type=${params.type} initiatorOrigin=${params.documentURL && new URL(params.documentURL).origin}`);
  } else if (method === "Network.requestWillBeSentExtraInfo" && seen.has(params.requestId)) {
    const h = params.headers;
    console.log(`${t()} ${params.requestId} wire-headers range=${h.Range ?? h.range ?? "-"} origin=${h.Origin ?? h.origin ?? "-"}`);
  } else if (method === "Network.responseReceived" && seen.has(params.requestId)) {
    const h = params.response.headers;
    console.log(`${t()} ${params.requestId} response ${params.response.status} content-range=${h["Content-Range"] ?? h["content-range"] ?? "-"} length=${h["Content-Length"] ?? h["content-length"] ?? "-"}`);
  } else if (method === "Network.loadingFailed" && seen.has(params.requestId)) {
    console.log(`${t()} ${params.requestId} failed ${params.errorText} canceled=${params.canceled}`);
  } else if (method === "Network.loadingFinished" && seen.has(params.requestId)) {
    console.log(`${t()} ${params.requestId} finished bytes=${params.encodedDataLength}`);
  }
});
ws.send(JSON.stringify({ id: 1, method: "Network.enable", params: {} }));
console.log(`${t()} attached`);
