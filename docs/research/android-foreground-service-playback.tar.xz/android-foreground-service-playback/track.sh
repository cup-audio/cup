#!/usr/bin/env bash
# Usage: ANDROID_SERIAL=emulator-5602 track.sh <worker-port> <auth-port> <out-dir>.
# With test-worker-servers.ts running on the Mac: reverses both ports, launches the debug build
# against the test Worker (cupTestApiOrigin http://localhost:<worker-port>), signs in through the
# debug build's fake Google sign-in, converts the fake source, plays the narration track with the
# stub foreground service, and records the track's requests over CDP: a whole listen, a seek near
# the end, fresh range requests at 50 % and 90 %, and again after 3 minutes in the background with
# the screen off.
set -uo pipefail
source "$(dirname "$0")/env.sh"
wport="$1"; aport="$2"; out="$3"; mkdir -p "${out}"
eval_js() { node "${here}/cdp-eval.mjs" 9334 "$1"; }
adb reverse "tcp:${wport}" "tcp:${wport}"
adb reverse "tcp:${aport}" "tcp:${aport}"
adb install -r "${REPO}/apps/mobile-app/android/app/build/outputs/apk/debug/app-debug.apk" >/dev/null
adb shell pm clear audio.cup.app
adb shell pm grant audio.cup.app android.permission.POST_NOTIFICATIONS
adb shell am start -n audio.cup.app/.MainActivity --es cupTestApiOrigin "http://localhost:${wport}"
sleep 8
adb forward --remove tcp:9334 2>/dev/null || true
adb forward tcp:9334 "localabstract:webview_devtools_remote_$(adb shell pidof audio.cup.app | tr -d '\r')"
eval_js "$(cat "${here}/track-probe.js")"
eval_js "window.__track.signInAndConvert('https://source.example.test/fixture')"
node "${here}/cdp-network.mjs" 9334 "narration-track" > "${out}/network.txt" &
net=$!
sleep 1
eval_js "Capacitor.Plugins.ProbeForegroundService.start()"
eval_js "window.__track.play()" | tee "${out}/play.json"
sleep 2
eval_js "new Promise(r => { const a = window.__cupAudio; if (a.ended) return r('ended'); a.addEventListener('ended', () => r('ended'), { once: true }); setTimeout(() => r('timeout'), 120000); })"
eval_js "window.__track.seekNearEndAndListen()" > /dev/null
eval_js "window.__track.freshElementSeek(0.5)"
eval_js "window.__track.freshElementSeek(0.9)"
adb shell input keyevent KEYCODE_HOME
adb shell input keyevent 26
sleep 180
eval_js "window.__trackLogPush('after 180 s hidden, screen off'), window.__track.freshElementSeek(0.9)"
eval_js "(window.__cupAudio.currentTime = 0, window.__cupAudio.play().then(() => 'replaying'))"
sleep 5
adb shell input keyevent KEYCODE_WAKEUP
adb shell wm dismiss-keyguard
adb shell am start -n audio.cup.app/.MainActivity
sleep 3
eval_js "window.__trackLog" > "${out}/track-log.json"
eval_js "Capacitor.Plugins.ProbeForegroundService.stop()"
kill "${net}"
cat "${out}/track-log.json" "${out}/network.txt"
