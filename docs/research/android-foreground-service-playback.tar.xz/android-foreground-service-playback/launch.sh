#!/usr/bin/env bash
# Force-stops and launches Cup against production (no cupTestApiOrigin), then forwards its devtools
# socket to localhost:9333.
set -euo pipefail
source "$(dirname "$0")/env.sh"
adb shell am force-stop audio.cup.app
adb shell am start -n audio.cup.app/.MainActivity "$@"
sleep 8
adb forward --remove tcp:9333 2>/dev/null || true
adb forward tcp:9333 "localabstract:webview_devtools_remote_$(adb shell pidof audio.cup.app | tr -d '\r')"
