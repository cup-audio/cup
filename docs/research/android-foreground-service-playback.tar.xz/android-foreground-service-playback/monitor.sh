#!/usr/bin/env bash
# Usage: monitor.sh <seconds> <interval>. Prints one line per interval: elapsed seconds, then for
# Cup's app process and Cup's WebView renderer (the sandboxed_process whose record ends in
# u0a<cup>i<n>): pid, curProcState and isFrozen; whether a Cup foreground service is running; and
# whether the screen is on. Reads only dumpsys and ps, never the devtools socket, which can hang adb
# while Cup is frozen.
source "$(dirname "$0")/env.sh"
total="${1:-660}"; step="${2:-30}"; start=$(date +%s)
uid="$(adb shell dumpsys package audio.cup.app | grep -m1 -oE 'appId=[0-9]+' | cut -d= -f2)"
tag="u0a$((uid - 10000))"
while :; do
  now=$(( $(date +%s) - start ))
  procs="$(adb shell dumpsys activity processes audio.cup.app | awk -v tag="${tag}" '
    /^ *\*APP\* .*ProcessRecord\{/ { name = ($0 ~ /sandboxed_process/) ? "renderer" : "app"; keep = ($0 ~ tag); match($0, /[0-9]+:/); pid = substr($0, RSTART, RLENGTH - 1) }
    keep && /curProcState=/ { match($0, /curProcState=[0-9]+/); st[name] = substr($0, RSTART + 13, RLENGTH - 13) ; p[name] = pid }
    keep && /isFrozen=/ { match($0, /isFrozen=[a-z]+/); fr[name] = substr($0, RSTART + 9, RLENGTH - 9) }
    END { for (n in st) printf "%s(pid=%s state=%s frozen=%s) ", n, p[n], st[n], fr[n] }')"
  fgs="$(adb shell dumpsys activity services audio.cup.app | grep -c 'isForeground=true')"
  screen="$(adb shell dumpsys power | grep -m1 -oE 'mWakefulness=[A-Za-z]+')"
  echo "${now}s ${procs}fgs=${fgs} ${screen}"
  [ "${now}" -ge "${total}" ] && break
  sleep "${step}"
done
