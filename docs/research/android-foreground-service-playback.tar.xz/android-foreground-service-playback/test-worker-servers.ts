// Usage: node test-worker-servers.ts <repo-root>. Starts the mobile E2E suite's fake auth provider
// (at http://localhost:<port>) and a test Worker that verifies its tokens, prints both ports as
// JSON, and keeps them running until SIGINT/SIGTERM. Reverse both ports to the emulator with
// `adb reverse tcp:<port> tcp:<port>`, as the suite does.
import path from "node:path";

const repo = process.argv[2] ?? process.cwd();
const { startAuthProvider, startTestWorker } = await import(
  path.join(repo, "qa/test-worker/src/index.ts")
);

const authProvider = await startAuthProvider({ hostname: "localhost" });
const worker = await startTestWorker({ authProviderOrigin: authProvider.origin });
const port = (origin: string) => Number(new URL(origin).port);
console.log(JSON.stringify({ worker: port(worker.origin), authProvider: port(authProvider.origin) }));

const stop = async () => {
  const media = worker.requests().filter((r: { path: string }) => r.path.includes("narration-track"));
  console.log(JSON.stringify(media.map((r: { method: string; path: string; headers: Record<string, string> }) => ({
    method: r.method,
    path: r.path.replace(/token=[^&]+/, "token=<redacted>"),
    range: r.headers["range"],
    origin: r.headers["origin"],
  })), null, 1));
  await worker.stop();
  await authProvider.close();
  process.exit(0);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
setInterval(() => {}, 1 << 30);
