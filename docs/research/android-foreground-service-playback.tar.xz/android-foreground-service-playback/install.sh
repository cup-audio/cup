#!/usr/bin/env bash
# Installs the debug APK built from the worktree with the stub plugin, grants notifications,
# launches Cup against production and forwards its devtools socket to localhost:9333.
set -euo pipefail
source "$(dirname "$0")/env.sh"
repo="${1:?repository root}"
adb install -r "${repo}/apps/mobile-app/android/app/build/outputs/apk/debug/app-debug.apk"
adb shell pm grant audio.cup.app android.permission.POST_NOTIFICATIONS
