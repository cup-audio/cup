// Combines the baseline's stream-probe.js and fetch-probe.js. Set window.__useFgs before
// evaluating. Shows a full-screen button whose tap starts the throwaway ProbeForegroundService
// (when window.__useFgs is true) and plays a 19-minute, 64 kbps LibriVox MP3 from archive.org.
// Every 5 s it records the position, the buffered end and the element's states; every 15 s it
// requests https://cup.audio/ (GET) through the CapacitorHttp plugin and through the patched fetch.
// Everything lands in window.__probe.log, read once Cup is back in the foreground.
(() => {
  const audio = new Audio("https://archive.org/download/pride_and_prejudice_librivox/prideandprejudice_01-03_austen_64kb.mp3");
  window.__audio = audio;
  clearInterval(window.__probeTimer);
  clearInterval(window.__netTimer);
  window.__probe = { log: [], start: Date.now() };
  const t = () => Math.round((Date.now() - window.__probe.start) / 1000);
  const bufferedEnd = () => (audio.buffered.length ? audio.buffered.end(audio.buffered.length - 1) : 0);
  const push = (e) =>
    window.__probe.log.push(
      `${t()}s ${document.visibilityState} at=${audio.currentTime.toFixed(0)} buffered=${bufferedEnd().toFixed(0)} paused=${audio.paused} ready=${audio.readyState} net=${audio.networkState} ${e}`,
    );
  for (const type of ["playing", "waiting", "stalled", "suspend", "error", "pause", "ended"]) {
    audio.addEventListener(type, () => push(`event:${type}${audio.error ? " code=" + audio.error.code : ""}`));
  }
  document.addEventListener("visibilitychange", () => push("visibilitychange"));
  const button = document.createElement("button");
  button.textContent = window.__useFgs ? "PROBE PLAY + FGS" : "PROBE PLAY";
  button.style.cssText = "position:fixed;inset:0;z-index:99999;font-size:40px";
  button.onclick = async () => {
    if (window.__useFgs) {
      try {
        const r = await Capacitor.Plugins.ProbeForegroundService.start();
        push("fgs " + JSON.stringify(r));
      } catch (e) {
        push("fgs ERR " + (e && e.message));
      }
    }
    audio.play().then(() => button.remove(), (e) => (button.textContent = String(e)));
  };
  document.body.append(button);
  window.__probeTimer = setInterval(() => push("tick"), 5000);
  window.__netTimer = setInterval(() => {
    Capacitor.Plugins.CapacitorHttp.request({ url: "https://cup.audio/", method: "GET" }).then(
      (r) => push("plugin ok " + r.status),
      (e) => push("plugin ERR " + (e && e.message)),
    );
    fetch("https://cup.audio/").then(
      (r) => push("fetch ok " + r.status),
      (e) => push("fetch ERR " + e.name + ": " + e.message),
    );
  }, 15000);
  return "ready fgs=" + Boolean(window.__useFgs);
})()
