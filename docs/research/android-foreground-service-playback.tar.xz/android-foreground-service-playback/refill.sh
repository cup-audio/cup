#!/usr/bin/env bash
# Usage: refill.sh <fgs true|false> <background true|false> <speed: full|80> <out-dir> [idle-seconds] [screen-off true|false].
# Checks whether the WebView refills the MP3's buffer: plays fgs-probe.js's MP3, waits until about
# 412 s are buffered, seeks to 395 s so playback reaches the buffered end within 20 s, then (when
# <background>) presses HOME, and records the media requests to archive.org over CDP for 90 s.
set -uo pipefail
source "$(dirname "$0")/env.sh"
fgs="$1"; bg="$2"; speed="$3"; out="$4"; idle="${5:-0}"; lock="${6:-false}"; mkdir -p "${out}"
adb emu network speed full >/dev/null
bash "${here}/launch.sh"
node "${here}/cdp-network.mjs" 9333 "archive.org" > "${out}/network.txt" &
net=$!
sleep 1
node "${here}/cdp-eval.mjs" 9333 "window.__useFgs = ${fgs}; $(cat "${here}/fgs-probe.js")"
adb shell input tap 540 1200
sleep 12
adb emu network speed "${speed}" >/dev/null
[ "${bg}" = true ] && adb shell input keyevent KEYCODE_HOME
[ "${lock}" = true ] && adb shell input keyevent 26
sleep "${idle}"   # idle with the download suspended before the seek
node "${here}/cdp-eval.mjs" 9333 "window.__audio.currentTime = 395, 'seeked'"
sleep 90
bash "${here}/monitor.sh" 0 1 | tee "${out}/monitor.txt"
[ "${lock}" = true ] && adb shell input keyevent KEYCODE_WAKEUP && adb shell wm dismiss-keyguard
[ "${bg}" = true ] && adb shell am start -n audio.cup.app/.MainActivity && sleep 3
adb emu network speed full >/dev/null
node "${here}/cdp-eval.mjs" 9333 "window.__probe.log.filter(l => !/plugin|fetch/.test(l))" > "${out}/probe-log.json"
node "${here}/cdp-eval.mjs" 9333 "window.__audio.pause(), clearInterval(window.__probeTimer), clearInterval(window.__netTimer), Capacitor.Plugins.ProbeForegroundService.stop()" >/dev/null
kill "${net}"
tail -n 12 "${out}/probe-log.json"; cat "${out}/network.txt"
