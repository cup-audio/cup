// Page helpers for the signed track URL check against the local test Worker. Evaluate once after
// launch; then call the async helpers through cdp-eval.mjs. The web player's <audio> is not in the
// DOM, so HTMLMediaElement.prototype.play records the element it is called on.
(() => {
  window.__trackLog = [];
  const start = Date.now();
  const log = (e) => {
    const a = window.__cupAudio;
    const b = a && a.buffered.length ? a.buffered.end(a.buffered.length - 1).toFixed(1) : "-";
    window.__trackLog.push(`${((Date.now() - start) / 1000).toFixed(1)}s ${document.visibilityState} ${a ? `at=${a.currentTime.toFixed(1)}/${a.duration.toFixed(1)} buffered=${b} paused=${a.paused} err=${a.error && a.error.code}` : "no-audio"} ${e}`);
  };
  window.__trackLogPush = log;
  const play = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function (...args) {
    if (window.__cupAudio !== this) {
      window.__cupAudio = this;
      for (const type of ["playing", "waiting", "stalled", "seeking", "seeked", "error", "pause", "ended"]) {
        this.addEventListener(type, () => log(`event:${type}`));
      }
    }
    return play.apply(this, args);
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const until = async (fn, what, ms = 60000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await sleep(250);
    }
    throw new Error("timeout: " + what);
  };
  const button = (label) =>
    [...document.querySelectorAll("button")].find((b) => (b.getAttribute("aria-label") ?? b.textContent.trim()) === label && !b.disabled);
  window.__track = {
    async signInAndConvert(sourceUrl) {
      const input = await until(() => document.querySelector('input[type="url"]'), "url input");
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, sourceUrl);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      (await until(() => button("Listen"), "Listen")).click();
      (await until(() => button("Continue with Google"), "Continue with Google")).click();
      await until(() => location.pathname.startsWith("/app/audiobooks/"), "audiobook page");
      return location.pathname;
    },
    async play() {
      (await until(() => button("Play"), "Play button", 180000)).click();
      await until(() => window.__cupAudio && !window.__cupAudio.paused && window.__cupAudio.currentTime > 0, "playing");
      log("play clicked");
      return { src: window.__cupAudio.currentSrc.replace(/token=[^&]+/, "token=<redacted>"), duration: window.__cupAudio.duration };
    },
    async seekNearEndAndListen() {
      const a = window.__cupAudio;
      a.currentTime = Math.max(0, a.duration - 3);
      if (a.paused) await a.play();
      log("seeked near end");
      await until(() => a.ended || a.paused, "ended", 30000);
      return window.__trackLog;
    },
    async freshElementSeek(fraction) {
      // A second element on the same signed URL, seeked before it buffered, forces a fresh range request.
      const a = new Audio(window.__cupAudio.currentSrc);
      a.preload = "auto";
      await until(() => a.readyState >= 1 || a.error, "metadata", 30000);
      a.currentTime = a.duration * fraction;
      await new Promise((r) => a.addEventListener("seeked", r, { once: true }));
      await a.play().catch((e) => log("fresh play ERR " + e));
      await sleep(1500);
      a.pause();
      const r = `fresh element seek to ${fraction}: at=${a.currentTime.toFixed(1)} err=${a.error && a.error.code}`;
      log(r);
      return r;
    },
  };
  return "track helpers ready";
})()
