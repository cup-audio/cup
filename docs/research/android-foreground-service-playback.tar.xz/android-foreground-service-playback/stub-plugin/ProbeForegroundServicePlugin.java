package audio.cup.app;

import android.content.Intent;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Throwaway probe (issue 373): starts and stops a mediaPlayback foreground service from JS. */
@CapacitorPlugin(name = "ProbeForegroundService")
public class ProbeForegroundServicePlugin extends Plugin {
    @PluginMethod
    public void start(PluginCall call) {
        Intent intent = new Intent(getContext(), ProbeMediaPlaybackService.class);
        ContextCompat.startForegroundService(getContext(), intent);
        JSObject result = new JSObject();
        result.put("started", true);
        call.resolve(result);
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().stopService(new Intent(getContext(), ProbeMediaPlaybackService.class));
        JSObject result = new JSObject();
        result.put("stopped", true);
        call.resolve(result);
    }
}
