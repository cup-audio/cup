package audio.cup.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

/** Throwaway probe (issue 373): a foreground service of type mediaPlayback with a minimal notification. */
public class ProbeMediaPlaybackService extends Service {
    private static final String CHANNEL_ID = "probe_playback";
    private static final int NOTIFICATION_ID = 373;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(
            new NotificationChannel(CHANNEL_ID, "Probe playback", NotificationManager.IMPORTANCE_LOW)
        );
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Cup probe")
            .setContentText("mediaPlayback foreground service")
            .setOngoing(true)
            .build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        Log.i("CupProbe", "startForeground mediaPlayback done");
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        Log.i("CupProbe", "service destroyed");
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
