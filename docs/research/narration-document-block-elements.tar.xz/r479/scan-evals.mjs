import { parseFragment } from "/Users/pkerschbaum/.claude/pkerschbaum-worktrees/cup/linear-integration-e5fbe3/node_modules/.pnpm/parse5@8.1.1/node_modules/parse5/dist/index.js";
import fs from "node:fs"; import path from "node:path";
const dir = process.argv[2];
const TAGS = ["table","pre","hr","dl","dt","dd","figure","figcaption","blockquote","ul","ol","li"];
const text = (n) => "value" in n ? n.value : (n.childNodes ?? []).map(text).join("");
for (const c of fs.readdirSync(dir)) {
  const html = fs.readFileSync(path.join(dir,c,"input.html"),"utf8");
  const exp = JSON.parse(fs.readFileSync(path.join(dir,c,"expected.json"),"utf8"));
  const all = exp.map(u=>u.narrationText).join("\n").replace(/\s+/g," ");
  const counts = {}; const kept = {}; const samples={};
  const nested = { listInList:0, bqInBq:0, listInBq:0 };
  (function walk(n, anc){ for (const ch of n.childNodes ?? []) { if(!("tagName" in ch)) continue;
    const t=ch.tagName;
    if (TAGS.includes(t)) { counts[t]=(counts[t]??0)+1;
      const tx=text(ch).replace(/\s+/g," ").trim().slice(0,60);
      if (tx.length>8 && all.includes(tx.slice(0,40))) { kept[t]=(kept[t]??0)+1; (samples[t]??=[]).push(tx.slice(0,50)); } }
    if ((t==="ul"||t==="ol") && anc.some(a=>a==="li")) nested.listInList++;
    if (t==="blockquote" && anc.includes("blockquote")) nested.bqInBq++;
    if ((t==="ul"||t==="ol") && anc.includes("blockquote")) nested.listInBq++;
    walk(ch.tagName==="template"?ch.content:ch,[...anc,t]); } })(parseFragment(html),[]);
  console.log("==",c, "\n counts",JSON.stringify(counts),"\n text-kept-in-expected",JSON.stringify(kept),"\n nested",JSON.stringify(nested));
  for (const t of ["table","pre","hr","dl","dt","dd","figure","figcaption","blockquote"]) if (samples[t]) console.log("  ",t,"kept e.g.",JSON.stringify(samples[t].slice(0,3)));
}
