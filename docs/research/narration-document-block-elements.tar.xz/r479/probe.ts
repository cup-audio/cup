import fs from "node:fs";

import { runSelection } from "/Users/pkerschbaum/.claude/pkerschbaum-worktrees/cup/linear-integration-e5fbe3/libs/narration-source-analysis/src/narration-content-selection.ts";
import { PRODUCTION_CONFIG } from "/Users/pkerschbaum/.claude/pkerschbaum-worktrees/cup/linear-integration-e5fbe3/libs/narration-source-analysis/src/production-narration-content-selection.ts";
import { createNarrationDocument } from "/Users/pkerschbaum/.claude/pkerschbaum-worktrees/cup/linear-integration-e5fbe3/libs/narration-document-creation/src/narration-document-creation.ts";
import { cleanAudiobookSourceMaterialHtml } from "/Users/pkerschbaum/.claude/pkerschbaum-worktrees/cup/linear-integration-e5fbe3/libs/prepare-source-material/src/prepare-source-material.ts";

const dir = process.argv[2]!;
const runs = Number(process.argv[3] ?? 2);
const raw = fs.readFileSync(`${dir}/probe-input.html`, "utf8");
const cleaned = cleanAudiobookSourceMaterialHtml(raw);
fs.writeFileSync(`${dir}/probe-cleaned.html`, cleaned);
let total = 0;
for (let run = 1; run <= runs; run++) {
  const sel = await runSelection({ configuration: PRODUCTION_CONFIG, sourceMaterialHtml: cleaned });
  const cost = sel.responses.reduce((s, r) => s + (r.usage.estimatedCostUsd ?? 0), 0);
  total += cost;
  const doc = createNarrationDocument({
    sourceTitle: "How Vienna moves",
    sourceMaterialHtml: sel.selectedSourceMaterialHtml,
  });
  const out = {
    run,
    requests: sel.responses.length,
    estimatedCostUsd: cost,
    usage: sel.responses.map((r) => r.usage),
    selectedSourceMaterialHtml: sel.selectedSourceMaterialHtml,
    html: doc.html,
    units: doc.synchronizationUnits,
  };
  fs.writeFileSync(`${dir}/probe-run-${run}.json`, JSON.stringify(out, null, 2));
  console.log(`run ${run}: requests=${out.requests} cost=$${cost.toFixed(5)} units=${doc.synchronizationUnits.length}`);
}
console.log(`total estimated cost $${total.toFixed(5)}`);
