import { createNarrationDocument } from "/Users/pkerschbaum/.claude/pkerschbaum-worktrees/cup/linear-integration-e5fbe3/libs/narration-document-creation/src/narration-document-creation.ts";
const F = {
  table: `<p>Intro.</p><table><caption>Results by runtime</caption><thead><tr><th>Metric</th><th>Kitesurf</th><th>Chromium</th></tr></thead><tbody><tr><td>CPU: screenshot</td><td>380 ms</td><td>1,173 ms</td></tr><tr><td>Memory</td><td><p>12 MB</p></td><td><ul><li>40 MB</li><li>cold</li></ul></td></tr></tbody></table><p>Outro.</p>`,
  pre: `<p>Run this:</p><pre><code>npm install
npx cup convert --url https://example.com
  echo "done"</code></pre><p>Then this poem:</p><pre>Roses are red,
   violets are blue.</pre>`,
  hr: `<p>Before the rule.</p><hr><p>After the rule.</p><p>Text<hr>split</p>`,
  dl: `<dl><dt>Synchronization unit</dt><dd>The smallest navigable portion.</dd><dt>Segment</dt><dt>Track</dt><dd><p>User-facing name.</p><p>Second paragraph.</p></dd></dl>`,
  figure: `<p>Before.</p><figure><img src="a.png" alt="A chart showing growth"><figcaption>Figure 1: Growth over <em>time</em>.</figcaption></figure><figure><blockquote><p>Ich bin ein Berliner.</p></blockquote><figcaption>— John F. Kennedy</figcaption></figure>`,
  nestedList: `<ul><li>Top one<ul><li>Nested a</li><li>Nested b<ol><li>Deep i</li></ol></li></ul></li><li><p>Top two para</p><p>Second para in item</p></li><li>Top three with <strong>bold</strong> and <a href="/x">link</a></li></ul>`,
  blockquote: `<blockquote>Bare quote text<cite>Someone</cite></blockquote><blockquote><p>Quoted para.</p><blockquote><p>Nested quote.</p></blockquote><ul><li>List in quote</li></ul><footer>— Author</footer></blockquote>`,
  headingBeforeTable: `<h2>Results</h2><table><tr><td>A</td><td>B</td></tr></table>`,
  headingBeforeBlockquote: `<h2>Voices</h2><blockquote><p>Quoted.</p></blockquote><p>After.</p>`,
  headingBeforeList: `<h2>Next steps</h2><ol><li>First</li><li>Second</li></ol>`,
  longPre: `<pre>${Array.from({ length: 120 }, (_, i) => `line ${i} of a long listing that keeps going`).join("\n")}</pre>`,
};
for (const [name, html] of Object.entries(F)) {
  const d = createNarrationDocument({ sourceTitle: "T", sourceMaterialHtml: html });
  console.log(`### ${name}\nINPUT: ${html}\nHTML: ${d.html}\nUNITS:`);
  for (const u of d.synchronizationUnits.slice(1)) console.log(`  ${u.id}: ${JSON.stringify(u.narrationText)}`);
  console.log();
}
